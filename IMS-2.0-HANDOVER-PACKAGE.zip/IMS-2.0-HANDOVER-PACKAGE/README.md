# IMS 2.0 - Railway Deployment

Production deployment of IMS 2.0 Retail Operating System on Railway.

## Architecture

- **Backend**: FastAPI (Python) - Port 8000
- **Frontend**: React + Vite + Netlify
- **Database**: MongoDB on Railway

## Backend Deployment (Railway)

The backend service is configured to run from the `ims-2.0-core/backend` directory.

### Environment Variables Required

```
MONGODB_URL=<from Railway MongoDB service>
JWT_SECRET_KEY=<generate with: openssl rand -hex 32>
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=10080
CORS_ORIGINS=https://ims-2-0-frontend.netlify.app,http://localhost:5173
```

### Build Configuration

- **Root Directory**: `ims-2.0-core/backend`
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `uvicorn api.main:app --host 0.0.0.0 --port $PORT`

## Frontend Deployment (Netlify)

The frontend is deployed separately on Netlify from the `ims-2.0-core/frontend` directory.

### Environment Variables Required

```
VITE_API_URL=https://ims-20-railway-production.up.railway.app
```

## Database Initialization

Run the seed script to create initial users:

```bash
# Connect to Railway MongoDB using mongosh
mongosh "<railway-mongodb-connection-string>"

# Then run:
use ims_db
load("ims-2.0-core/scripts/seed-users.js")
```

Or use MongoDB Compass to import the users from `ims-2.0-core/scripts/seed-users.js`.

## Default Login Credentials

**Admin:**
- Username: `admin`
- Password: `admin123`

**CEO:**
- Username: `avinash.ceo`
- Password: `Ceo@2024`

⚠️ **Change passwords after first login!**

## Services

- **Backend API**: https://ims-20-railway-production.up.railway.app
- **Frontend**: https://ims-2-0-frontend.netlify.app
- **API Docs**: https://ims-20-railway-production.up.railway.app/docs

## Monitoring

- Railway Dashboard: https://railway.app/dashboard
- Netlify Dashboard: https://app.netlify.com

---

**Version**: 2.0.0
**Status**: Production Ready
