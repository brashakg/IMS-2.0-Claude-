// ============================================================================
// IMS 2.0 - Workshop Page
// ============================================================================
// NO MOCK DATA - All data from API

import { useState, useEffect } from 'react';
import {
  Wrench,
  Clock,
  CheckCircle,
  AlertTriangle,
  Search,
  Eye,
  Phone,
  User,
  Zap,
  Timer,
  Loader2,
  RefreshCw,
  X,
  ChevronRight,
  Calendar,
  Package,
  FileText,
} from 'lucide-react';
import type { JobStatus, JobPriority } from '../../types';
import { workshopApi } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import clsx from 'clsx';

// Job type
interface Job {
  id: string;
  jobNumber: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  frameName: string;
  frameBarcode?: string;
  lensType: string;
  status: JobStatus;
  priority: JobPriority;
  assignedTo?: string;
  expectedDate: string;
  promisedDate: string;
  createdAt: string;
  completedAt?: string;
  notes?: string;
}

const STATUS_CONFIG: Record<JobStatus, { label: string; class: string; step: number }> = {
  CREATED: { label: 'Created', class: 'bg-gray-100 text-gray-600', step: 1 },
  LENS_ORDERED: { label: 'Lens Ordered', class: 'bg-blue-100 text-blue-600', step: 2 },
  LENS_RECEIVED: { label: 'Lens Received', class: 'bg-indigo-100 text-indigo-600', step: 3 },
  IN_PROGRESS: { label: 'Fitting', class: 'bg-yellow-100 text-yellow-600', step: 4 },
  QC_PENDING: { label: 'QC Pending', class: 'bg-orange-100 text-orange-600', step: 5 },
  QC_PASSED: { label: 'QC Passed', class: 'bg-teal-100 text-teal-600', step: 6 },
  QC_FAILED: { label: 'QC Failed', class: 'bg-red-100 text-red-600', step: 5 },
  READY: { label: 'Ready', class: 'bg-green-100 text-green-600', step: 7 },
  DELIVERED: { label: 'Delivered', class: 'bg-emerald-100 text-emerald-600', step: 8 },
  CANCELLED: { label: 'Cancelled', class: 'bg-red-100 text-red-600', step: 0 },
};

const PRIORITY_CONFIG: Record<JobPriority, { label: string; class: string; icon: React.ComponentType<{ className?: string }> }> = {
  NORMAL: { label: 'Normal', class: 'text-gray-500', icon: Clock },
  EXPRESS: { label: 'Express', class: 'text-orange-500', icon: Timer },
  URGENT: { label: 'Urgent', class: 'text-red-500', icon: Zap },
};

// Status transition flow
const STATUS_FLOW: Record<JobStatus, JobStatus[]> = {
  CREATED: ['LENS_ORDERED', 'CANCELLED'],
  LENS_ORDERED: ['LENS_RECEIVED', 'CANCELLED'],
  LENS_RECEIVED: ['IN_PROGRESS', 'CANCELLED'],
  IN_PROGRESS: ['QC_PENDING', 'CANCELLED'],
  QC_PENDING: ['QC_PASSED', 'QC_FAILED'],
  QC_PASSED: ['READY'],
  QC_FAILED: ['IN_PROGRESS'],
  READY: ['DELIVERED'],
  DELIVERED: [],
  CANCELLED: [],
};

// ============================================================================
// Job Details Modal Component
// ============================================================================
interface JobDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStatusUpdate: () => void;
  job: Job;
}

function JobDetailsModal({ isOpen, onClose, onStatusUpdate, job }: JobDetailsModalProps) {
  const toast = useToast();
  const { hasRole } = useAuth();
  const [isUpdating, setIsUpdating] = useState(false);

  const canUpdateStatus = hasRole(['SUPERADMIN', 'ADMIN', 'STORE_MANAGER', 'WORKSHOP_STAFF']);
  const statusConfig = STATUS_CONFIG[job.status];
  const priorityConfig = PRIORITY_CONFIG[job.priority];
  const PriorityIcon = priorityConfig.icon;
  const nextStatuses = STATUS_FLOW[job.status] || [];

  const handleStatusChange = async (newStatus: JobStatus) => {
    setIsUpdating(true);
    try {
      await workshopApi.updateJobStatus(job.id, newStatus);
      toast.success(`Job status updated to ${STATUS_CONFIG[newStatus].label}`);
      onStatusUpdate();
      onClose();
    } catch (err) {
      console.error('Failed to update job status:', err);
      toast.error('Failed to update job status');
    } finally {
      setIsUpdating(false);
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  const formatTime = (dateStr: string) => {
    return new Date(dateStr).toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const isOverdue = new Date(job.promisedDate) < new Date() && !['READY', 'DELIVERED', 'CANCELLED'].includes(job.status);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold text-gray-900">{job.jobNumber}</h2>
              <span className={clsx('px-2 py-0.5 rounded-full text-xs font-medium', statusConfig.class)}>
                {statusConfig.label}
              </span>
            </div>
            <p className="text-sm text-gray-500">Order: {job.orderNumber}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Priority & Dates */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2">
              <PriorityIcon className={clsx('w-5 h-5', priorityConfig.class)} />
              <span className={clsx('font-medium', priorityConfig.class)}>{priorityConfig.label} Priority</span>
            </div>
            {isOverdue && (
              <span className="badge-error flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                Overdue
              </span>
            )}
          </div>

          {/* Customer Info */}
          <div className="p-3 border border-gray-200 rounded-lg">
            <p className="text-sm font-medium text-gray-500 mb-2">Customer</p>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-bv-red-100 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-bv-red-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">{job.customerName}</p>
                <p className="text-sm text-gray-500 flex items-center gap-1">
                  <Phone className="w-3 h-3" />
                  {job.customerPhone}
                </p>
              </div>
            </div>
          </div>

          {/* Product Details */}
          <div className="p-3 border border-gray-200 rounded-lg">
            <p className="text-sm font-medium text-gray-500 mb-2">Product Details</p>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-gray-400" />
                <span className="font-medium">{job.frameName}</span>
                {job.frameBarcode && (
                  <span className="text-xs text-gray-500">({job.frameBarcode})</span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-gray-400" />
                <span>{job.lensType}</span>
              </div>
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 border border-gray-200 rounded-lg">
              <p className="text-sm font-medium text-gray-500 mb-1">Created</p>
              <div className="flex items-center gap-1 text-gray-900">
                <Calendar className="w-4 h-4 text-gray-400" />
                <span>{formatDate(job.createdAt)}</span>
              </div>
              <p className="text-xs text-gray-500">{formatTime(job.createdAt)}</p>
            </div>
            <div className={clsx(
              'p-3 border rounded-lg',
              isOverdue ? 'border-red-300 bg-red-50' : 'border-gray-200'
            )}>
              <p className="text-sm font-medium text-gray-500 mb-1">Promise Date</p>
              <div className={clsx(
                'flex items-center gap-1',
                isOverdue ? 'text-red-600' : 'text-gray-900'
              )}>
                <Calendar className="w-4 h-4" />
                <span className="font-medium">{formatDate(job.promisedDate)}</span>
              </div>
            </div>
          </div>

          {/* Notes */}
          {job.notes && (
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <FileText className="w-4 h-4 text-yellow-600" />
                <p className="text-sm font-medium text-yellow-800">Notes</p>
              </div>
              <p className="text-sm text-yellow-700">{job.notes}</p>
            </div>
          )}

          {/* Assigned To */}
          {job.assignedTo && (
            <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
              <span className="text-sm text-gray-500">Assigned To</span>
              <span className="font-medium text-gray-900">{job.assignedTo}</span>
            </div>
          )}

          {/* Progress */}
          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-gray-500">Progress</span>
              <span className="text-gray-500">Step {statusConfig.step} of 8</span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={clsx(
                  'h-full transition-all duration-300',
                  job.status === 'QC_FAILED' ? 'bg-red-500' : 'bg-bv-red-600'
                )}
                style={{ width: `${(statusConfig.step / 8) * 100}%` }}
              />
            </div>
          </div>

          {/* Status Update Actions */}
          {canUpdateStatus && nextStatuses.length > 0 && (
            <div className="pt-4 border-t border-gray-200">
              <p className="text-sm font-medium text-gray-700 mb-2">Update Status</p>
              <div className="flex flex-wrap gap-2">
                {nextStatuses.map(nextStatus => {
                  const nextConfig = STATUS_CONFIG[nextStatus];
                  return (
                    <button
                      key={nextStatus}
                      onClick={() => handleStatusChange(nextStatus)}
                      disabled={isUpdating}
                      className={clsx(
                        'px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-1 transition-colors',
                        nextStatus === 'CANCELLED'
                          ? 'bg-red-100 text-red-700 hover:bg-red-200'
                          : 'bg-bv-red-100 text-bv-red-700 hover:bg-bv-red-200',
                        isUpdating && 'opacity-50 cursor-not-allowed'
                      )}
                    >
                      {isUpdating ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <ChevronRight className="w-4 h-4" />
                      )}
                      {nextConfig.label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200">
          <button
            onClick={onClose}
            className="btn-outline w-full"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export function WorkshopPage() {
  const { user, hasRole } = useAuth();
  const _toast = useToast();
  // Toast reserved for future use in page-level notifications
  void _toast;

  // Data state
  const [jobs, setJobs] = useState<Job[]>([]);

  // UI state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<JobStatus | 'ALL' | 'ACTIVE'>('ACTIVE');
  const [priorityFilter, setPriorityFilter] = useState<JobPriority | 'ALL'>('ALL');

  // Modal state
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);

  // Loading state
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Role-based permissions
  const _canUpdateStatus = hasRole(['SUPERADMIN', 'ADMIN', 'STORE_MANAGER', 'WORKSHOP_STAFF']);
  const _canAssignJob = hasRole(['SUPERADMIN', 'ADMIN', 'STORE_MANAGER']);
  // Reserved for future job status update and assignment features
  void _canUpdateStatus;
  void _canAssignJob;

  // Load jobs on mount
  useEffect(() => {
    loadJobs();
  }, [user?.activeStoreId]);

  const loadJobs = async () => {
    if (!user?.activeStoreId) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await workshopApi.getJobs(user.activeStoreId);
      const jobsData = response?.jobs || response || [];
      setJobs(Array.isArray(jobsData) ? jobsData : []);
    } catch (err) {
      console.error('Failed to load jobs:', err);
      setError('Failed to load workshop jobs. Please try again.');
      setJobs([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Filter jobs locally
  const filteredJobs = jobs.filter(job => {
    const matchesSearch = !searchQuery ||
      job.jobNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.customerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.orderNumber?.toLowerCase().includes(searchQuery.toLowerCase());

    let matchesStatus = true;
    if (statusFilter === 'ACTIVE') {
      matchesStatus = !['DELIVERED', 'CANCELLED'].includes(job.status);
    } else if (statusFilter !== 'ALL') {
      matchesStatus = job.status === statusFilter;
    }

    const matchesPriority = priorityFilter === 'ALL' || job.priority === priorityFilter;

    return matchesSearch && matchesStatus && matchesPriority;
  });

  // Stats
  const activeJobs = jobs.filter(j => !['DELIVERED', 'CANCELLED'].includes(j.status));
  const urgentJobs = activeJobs.filter(j => j.priority === 'URGENT');
  const readyJobs = jobs.filter(j => j.status === 'READY');
  const overdueJobs = activeJobs.filter(j => new Date(j.promisedDate) < new Date());

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
    });
  };

  const isOverdue = (promisedDate: string) => {
    return new Date(promisedDate) < new Date();
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Workshop</h1>
          <p className="text-gray-500">Manage lens fitting and job orders</p>
        </div>
        <button
          onClick={loadJobs}
          disabled={isLoading}
          className="btn-outline flex items-center gap-2"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4" />
          )}
          Refresh
        </button>
      </div>

      {/* Error State */}
      {error && (
        <div className="card bg-red-50 border-red-200">
          <div className="flex items-center gap-3 text-red-600">
            <AlertTriangle className="w-5 h-5" />
            <p>{error}</p>
            <button onClick={loadJobs} className="ml-auto text-sm underline">
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-2 tablet:grid-cols-4 gap-4">
        <div className="card">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Wrench className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Active Jobs</p>
              <p className="text-2xl font-bold text-gray-900">{activeJobs.length}</p>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Urgent</p>
              <p className="text-2xl font-bold text-red-600">{urgentJobs.length}</p>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Ready for Pickup</p>
              <p className="text-2xl font-bold text-green-600">{readyJobs.length}</p>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Overdue</p>
              <p className="text-2xl font-bold text-orange-600">{overdueJobs.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="flex flex-col tablet:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="input-field pl-10"
              placeholder="Search by job number, customer, order..."
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value as typeof statusFilter)}
              className="input-field w-auto"
            >
              <option value="ACTIVE">Active Jobs</option>
              <option value="ALL">All Status</option>
              {Object.entries(STATUS_CONFIG).map(([status, config]) => (
                <option key={status} value={status}>{config.label}</option>
              ))}
            </select>
            <select
              value={priorityFilter}
              onChange={e => setPriorityFilter(e.target.value as typeof priorityFilter)}
              className="input-field w-auto"
            >
              <option value="ALL">All Priority</option>
              <option value="URGENT">Urgent</option>
              <option value="EXPRESS">Express</option>
              <option value="NORMAL">Normal</option>
            </select>
          </div>
        </div>
      </div>

      {/* Jobs List */}
      <div className="space-y-3">
        {isLoading ? (
          <div className="card flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-bv-red-600" />
          </div>
        ) : filteredJobs.length === 0 ? (
          <div className="card text-center py-12 text-gray-500">
            <Wrench className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>{searchQuery || statusFilter !== 'ACTIVE' || priorityFilter !== 'ALL' ? 'No jobs found matching your filters' : 'No workshop jobs'}</p>
          </div>
        ) : (
          filteredJobs.map(job => {
            const statusConfig = STATUS_CONFIG[job.status];
            const priorityConfig = PRIORITY_CONFIG[job.priority];
            const PriorityIcon = priorityConfig.icon;
            const overdue = isOverdue(job.promisedDate) && !['READY', 'DELIVERED', 'CANCELLED'].includes(job.status);

            return (
              <div
                key={job.id}
                className={clsx(
                  'card',
                  job.priority === 'URGENT' && 'border-red-300 bg-red-50',
                  overdue && job.priority !== 'URGENT' && 'border-orange-300 bg-orange-50'
                )}
              >
                <div className="flex items-start justify-between gap-4">
                  {/* Job Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-bold text-gray-900">{job.jobNumber}</span>
                      <span className={clsx('px-2 py-0.5 rounded-full text-xs font-medium', statusConfig.class)}>
                        {statusConfig.label}
                      </span>
                      <span className={clsx('flex items-center gap-1 text-xs font-medium', priorityConfig.class)}>
                        <PriorityIcon className="w-3 h-3" />
                        {priorityConfig.label}
                      </span>
                      {overdue && (
                        <span className="badge-error flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          Overdue
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Customer</p>
                        <p className="font-medium flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {job.customerName}
                        </p>
                        <p className="text-gray-500 flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {job.customerPhone}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-500">Frame & Lens</p>
                        <p className="font-medium">{job.frameName}</p>
                        <p className="text-gray-500">{job.lensType}</p>
                      </div>
                    </div>

                    {job.notes && (
                      <p className="mt-2 text-sm text-yellow-700 bg-yellow-50 px-2 py-1 rounded">
                        Note: {job.notes}
                      </p>
                    )}
                  </div>

                  {/* Dates & Actions */}
                  <div className="text-right">
                    <div className="mb-3">
                      <p className="text-xs text-gray-500">Promise Date</p>
                      <p className={clsx(
                        'font-medium',
                        overdue ? 'text-red-600' : 'text-gray-900'
                      )}>
                        {formatDate(job.promisedDate)}
                      </p>
                    </div>
                    {job.assignedTo && (
                      <p className="text-xs text-gray-500 mb-3">
                        Assigned: {job.assignedTo}
                      </p>
                    )}
                    <button
                      onClick={() => setSelectedJob(job)}
                      className="btn-outline text-sm flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </button>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-gray-500">Progress</span>
                    <span className="text-gray-500">{statusConfig.label}</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={clsx(
                        'h-full transition-all duration-300',
                        job.status === 'QC_FAILED' ? 'bg-red-500' : 'bg-bv-red-600'
                      )}
                      style={{ width: `${(statusConfig.step / 8) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Job Details Modal */}
      {selectedJob && (
        <JobDetailsModal
          isOpen={true}
          onClose={() => setSelectedJob(null)}
          onStatusUpdate={loadJobs}
          job={selectedJob}
        />
      )}
    </div>
  );
}

export default WorkshopPage;
